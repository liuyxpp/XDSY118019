# 期末考试第二部分答案

## 1. Minkowski 距离

### 输入校验与实现

`_validate_vector` 将输入转换为一维 NumPy 数组；`_validate_weights` 还会检查权重是否均为非负数。`minkowski` 函数会检查 `p` 是否大于 0，并确认两个向量以及可选权重的长度相同。

```python
import numpy as np
from scipy.linalg import norm


def _validate_vector(u, dtype=None):
    # 将输入转换为 NumPy 数组，并要求其为一维。
    u = np.asarray(u, dtype=dtype, order="c")
    if u.ndim == 1:
        return u
    raise ValueError("Input vector should be 1-D.")


def _validate_weights(w, dtype=np.float64):
    # 权重必须是一维向量，且每个权重都不能为负。
    w = _validate_vector(w, dtype=dtype)
    if np.any(w < 0):
        raise ValueError("Input weights should be all non-negative")
    return w


def minkowski(u, v, p=2, w=None):
    """计算两个一维数组之间的 Minkowski 距离。

    对于权重 w，距离定义为
    (sum(w_i * |u_i - v_i|**p))**(1/p).

    参数
    ----
    u, v : array_like
        长度相同的一维输入向量。
    p : 正标量
        范数的阶数。当 0 < p < 1 时，得到的是拟度量。
    w : array_like, optional
        可选的非负权重，每个向量元素对应一个权重。

    示例
    ----
    >>> minkowski([1, 0, 0], [0, 1, 0], 1)
    2.0
    >>> minkowski([1, 2, 3], [4, 5, 6], 2)
    5.196152422706632
    >>> minkowski([1, 2, 3], [4, 5, 6], 3)
    4.3267487109222245
    >>> minkowski([1, 2, 3], [4, 5, 6], np.inf)
    3.0
    >>> minkowski([1, 2, 3], [4, 5, 6], 2, w=[0.5, 0.5, 0.5])
    3.6742346141747673
    >>> minkowski([1, 2, 3], [4, 5, 6], 2, w=[1, 0, 0])
    3.0
    """
    if p <= 0:
        raise ValueError("p must be greater than 0")

    u = _validate_vector(u)
    v = _validate_vector(v)
    if u.shape != v.shape:
        raise ValueError("Input vectors u and v should have the same size.")

    if w is not None:
        w = _validate_weights(w)
        if w.shape != u.shape:
            raise ValueError("Input weights should have the same size as input vectors.")

    u_v = u - v
    if w is not None:
        # 先乘以 w**(1/p)，再计算普通 p 范数，从而实现加权距离。
        if p == 1:
            root_w = w
        elif p == 2:
            root_w = np.sqrt(w)
        elif p == np.inf:
            root_w = (w != 0)
        else:
            root_w = np.power(w, 1 / p)
        u_v = root_w * u_v

    return norm(u_v, ord=p)


if __name__ == "__main__":
    print(minkowski([1, 2, 3], [3, 2, 1], 2, w=[0.1, 0.7, 0.2]))
    print(minkowski([0, 1, 1, 0, 0, 1], [1, 0, 0, 1, 1, 0], 0.5))
    print(minkowski([0.1, 0.5, -0.3, -1.2], [-0.5, 1.5, 0.3, 0.6], 3))
```

```python
#u1 = [1,2,3], v1= [3,2,1], p= 2, w= [0.1, 0.7, 0.2]
print('1-iii-1_ans:', minkowski([1,2,3], [3,2,1], 2, w=[0.1, 0.7, 0.2]))#1.0954451150103321
#u2 = [0,1,1,0,0,1], v2= [1,0,0,1,1,0],p= 0.5
print('1-iii-2_ans:', minkowski([0,1,1,0,0,1], [1,0,0,1,1,0], 0.5))#36.0
#u3 = [0.1, 0.5, -0.3, -1.2], v3= [-0.5, 1.5, 0.3, 0.6], p= 3
print('1-iii-3_ans:', minkowski([0.1, 0.5, -0.3, -1.2], [-0.5, 1.5, 0.3, 0.6], 3))#1.9366833186578014
```

题目三组向量距离的计算结果依次为：

1. `1.0954451150103321`
2. `36.0`
3. `1.9366833186578014`

## 2. Klein 瓶（`surf` 绘图）

在 `[0, 2π]` 范围内为两个参数生成网格。`.*` 和 `.^` 分别表示逐元素乘法和逐元素乘方，用于在网格的每个点上计算参数方程；`surf` 则根据得到的坐标矩阵绘制曲面。

```matlab
sampleCount = 200;
u = linspace(0, 2*pi, sampleCount);
v = linspace(0, 2*pi, sampleCount);
[U, V] = meshgrid(u, v);

X = -(2/15) .* cos(U) .* ( ...
    3 .* cos(V) - 30 .* sin(U) + 90 .* cos(U).^4 .* sin(U) ...
    - 60 .* cos(U).^6 .* sin(U) + 5 .* cos(U) .* cos(V) .* sin(U));

Y = -(1/15) .* sin(U) .* ( ...
    3 .* cos(V) - 3 .* cos(U).^2 .* cos(V) ...
    - 48 .* cos(U).^4 .* cos(V) + 48 .* cos(U).^6 .* cos(V) ...
    - 60 .* sin(U) + 5 .* cos(U).^3 .* cos(V) .* sin(U) ...
    - 80 .* cos(U).^5 .* cos(V) .* sin(U) ...
    + 80 .* cos(U).^7 .* cos(V) .* sin(U));

Z = (2/15) .* (3 + 5 .* cos(U) .* sin(U)) .* sin(V);

figure('Color', 'w');
surf(X, Y, Z, 'EdgeColor', 'none');
shading interp;
colormap parula;
axis equal;
grid on;
view(45, 30);
xlabel('x');
ylabel('y');
zlabel('z');
title('Klein Bottle');
exportgraphics(gcf, 'klein_bottle_fig.png', 'Resolution', 300);
```

![使用 `surf` 绘制的 Klein 瓶曲面](klein_bottle_fig.png)

## 3. Mathematica 计算

### i. 无穷级数求和

```wolfram
ClearAll[n, x, t, seriesResult, tIntegral, integralResult, derivativeCheck];

seriesResult = FullSimplify[
   Sum[(-1)^(n + 1) Sin[n]/n, {n, 1, Infinity}]
   ];
Print[seriesResult];
```

计算结果为 **`1/2`**（以弧度为单位）。

### ii. 不定积分

令 `t = Sqrt[Tan[x]]`，则 `dx = 2 t/(1 + t^4) dt`，原积分可化为 `2 t^2/(1 + t^4)` 关于 `t` 的积分。

```wolfram
tIntegral = Integrate[2 t^2/(1 + t^4), t];
integralResult = FullSimplify[
   tIntegral /. t -> Sqrt[Tan[x]],
   Assumptions -> 0 < x < Pi/2
   ];
derivativeCheck = FullSimplify[
   D[integralResult, x] == Sqrt[Tan[x]],
   Assumptions -> 0 < x < Pi/2
   ];
Print[integralResult];
Print[derivativeCheck];
```

令 `t = Sqrt[Tan[x]]`，一个等价的原函数为

$$
\frac{1}{\sqrt{2}}\left[
\frac{1}{2}\ln\left(\frac{t^2-\sqrt{2}t+1}{t^2+\sqrt{2}t+1}\right)
+ \arctan(\sqrt{2}t-1)+\arctan(\sqrt{2}t+1)
\right]+C.
$$

在 `0 < x < π/2` 的范围内，导数检验结果为 `True`。

## 4. Navier–Stokes 方程

### Navier–Stokes Equations

The Navier–Stokes momentum equation can be derived as a particular form of the Cauchy momentum equation, whose general convective form is:

$$
\frac{D\mathbf{u}}{Dt} = \frac{1}{\rho}\nabla\cdot\boldsymbol{\sigma} + \mathbf{a}.
$$

By setting the Cauchy stress tensor $\boldsymbol{\sigma}$ to be the sum of a viscosity term $\boldsymbol{\tau}$ (the deviatoric stress) and a pressure term $-p\mathbf{I}$ (volumetric stress), we arrive at:

$$
\rho\frac{D\mathbf{u}}{Dt} = -\nabla p + \nabla\cdot\boldsymbol{\tau} + \rho\mathbf{a}.
$$

where

- $\frac{D}{Dt}$ is the material derivative, defined as $\frac{\partial}{\partial t} + \mathbf{u}\cdot\nabla$,
- $\rho$ is the (mass) density,
- $\mathbf{u}$ is the flow velocity,
- $\nabla\cdot$ is the divergence,
- $p$ is the pressure,
- $t$ is time,
- $\boldsymbol{\tau}$ is the Deviatoric stress|deviatoric stress tensor, which has order 2,
- $\mathbf{a}$ represents body forces acting on the continuum, for example gravity, Fictitious force|inertial accelerations, Coulomb's law|electrostatic accelerations, and so on.

In this form, it is apparent that in the assumption of an inviscid fluid – no deviatoric stress – Cauchy equations reduce to the [Euler equations](https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)).
